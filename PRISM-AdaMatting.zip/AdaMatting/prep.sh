#/bin/bash

python main.py \
    --mode=prep \
    --valid_portion=5 \
    --batch_size=16 \
    --epochs=120 \
    --lr=0.0001 \
